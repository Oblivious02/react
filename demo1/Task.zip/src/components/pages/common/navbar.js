function Navbar() {
  return (
    <div className="App2">
      <header class="main-header">
        <button id="side-menu-toggle">Menu</button>
        <nav class="main-header__nav">
          <ul class="main-header__item-list">
            <li class="main-header__item">
              <a class="" href="/">
                Shop
              </a>
            </li>
          </ul>
        </nav>
      </header>
    </div>
  );
}
export default Navbar;
